package com.sky.sec6001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sec6001ApplicationTests {

    @Test
    void contextLoads() {
    }

}
