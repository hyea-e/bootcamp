package com.sky.sec6001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sec6001Application {

    public static void main(String[] args) {
        SpringApplication.run(Sec6001Application.class, args);
    }

}
