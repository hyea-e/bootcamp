package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Security0327Application {

    public static void main(String[] args) {
        SpringApplication.run(Security0327Application.class, args);
    }

}
