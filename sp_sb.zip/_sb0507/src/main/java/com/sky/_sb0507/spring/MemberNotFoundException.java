package com.sky._sb0507.spring;

public class MemberNotFoundException extends RuntimeException {

}
