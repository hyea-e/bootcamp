package com.sky._sb0507.spring;

public class WrongIdPasswordException extends RuntimeException {

}
