package com.sky._sb0507;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb0507ApplicationTests {

    @Test
    void contextLoads() {
    }

}
