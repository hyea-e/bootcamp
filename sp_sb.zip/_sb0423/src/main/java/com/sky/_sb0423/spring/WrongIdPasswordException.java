package com.sky._sb0423.spring;

public class WrongIdPasswordException extends RuntimeException {

}
