package com.sky._sb0423.spring;

public class MemberNotFoundException extends RuntimeException {

}
