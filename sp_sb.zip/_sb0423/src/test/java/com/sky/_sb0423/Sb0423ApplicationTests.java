package com.sky._sb0423;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb0423ApplicationTests {

    @Test
    void contextLoads() {
    }

}
