package com.sky.sp5ch14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp5Ch14ApplicationTests {

    @Test
    void contextLoads() {
    }

}
