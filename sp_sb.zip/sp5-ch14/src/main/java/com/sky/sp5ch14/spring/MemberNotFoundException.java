package com.sky.sp5ch14.spring;

public class MemberNotFoundException extends RuntimeException {

}
