package com.sky.sp5ch14.spring;

public class WrongIdPasswordException extends RuntimeException {

}
