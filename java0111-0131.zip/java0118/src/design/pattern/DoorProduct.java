package design.pattern;

public abstract class DoorProduct { // 차문 제작
    public abstract String makeAssemble(); // 조립
}
