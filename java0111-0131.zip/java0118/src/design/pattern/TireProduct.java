package design.pattern;

public abstract class TireProduct { // 타이어 제작
    public abstract String makeAssemble();  // 조립
}
