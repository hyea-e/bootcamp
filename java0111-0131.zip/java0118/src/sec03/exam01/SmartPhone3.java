package sec03.exam01;

public class SmartPhone3 extends SmartPhone {

	public SmartPhone3(int x) {
		super(x);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String ring(int tel) {
		// TODO Auto-generated method stub
		return null;
	}

}
