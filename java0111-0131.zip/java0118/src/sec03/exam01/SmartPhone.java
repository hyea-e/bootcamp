package sec03.exam01;

public abstract class SmartPhone extends Phone {

	public SmartPhone(int x) {
		super(x);
		// TODO Auto-generated constructor stub
	}
	
	public abstract void test();
}
