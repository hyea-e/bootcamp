package sec01.exam02;

public class MyClass4 implements InterTest2{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test6() {
		// TODO Auto-generated method stub
		
	}

}
