package sec01.exam02;

public class MyClass3 implements InterTest {

	
	@Override
	public void test3() {
		// 재정의
	}

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

}
