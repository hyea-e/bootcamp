package sec01.exam02;

public class MyClass2 implements InterTest{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}

}
