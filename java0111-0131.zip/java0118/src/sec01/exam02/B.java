package sec01.exam02;

public interface B {
	void methodB();
}
