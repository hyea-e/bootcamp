package sec01.exam02;

public interface InterTest2 extends InterTest {
	void test6();
}
