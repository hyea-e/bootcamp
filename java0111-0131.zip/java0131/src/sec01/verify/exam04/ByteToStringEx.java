package sec01.verify.exam04;

public class ByteToStringEx {

	public static void main(String[] args) {
		byte[] bytes = {73, 32, 108, 111, 118};
		String str = new String(bytes);
		System.out.println(str);
	}

}
