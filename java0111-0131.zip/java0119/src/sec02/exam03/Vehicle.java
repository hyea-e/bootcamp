package sec02.exam03;

public interface Vehicle {
	public void run();
}
