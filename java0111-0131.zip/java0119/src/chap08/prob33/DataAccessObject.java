package chap08.prob33;

public interface DataAccessObject {
	void select();
	void insert();
	void update();
	void delete();
}
