package chap08.prob3;

public interface Soundable {
	String sound();
}
