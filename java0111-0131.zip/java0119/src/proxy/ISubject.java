package proxy;

public interface ISubject {
	void action();
}
