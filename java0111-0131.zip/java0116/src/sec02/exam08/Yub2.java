package sec02.exam08;

public class Yub2 extends Yub{
	int y;
	Yub2(int y) {
		super(3);
		this.y = y;
		System.out.println("생성자");
	}

}
