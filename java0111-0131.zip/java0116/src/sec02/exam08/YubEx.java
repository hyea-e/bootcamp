package sec02.exam08;

public class YubEx {

	public static void main(String[] args) {
		Yub2 yu = new Yub2(7);
		yu.print();
//		System.out.println(yu.x);
		
		

	}

}
