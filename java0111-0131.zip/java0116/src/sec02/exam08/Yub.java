package sec02.exam08;

public class Yub {
	int x;
	
	Yub(int x) {
		this.x = x;
		System.out.println("yub생성자");
	}
	
	void print() {
		System.out.println("x="+x);
	}
}
