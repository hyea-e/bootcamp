package java0116;

public class MyString //extends String { String은 final 클래스
{	String name;

}
