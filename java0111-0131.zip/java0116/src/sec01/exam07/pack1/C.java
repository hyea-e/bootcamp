package sec01.exam07.pack1;

public class C {
	public void method() {
		A a = new A();
		a.field = "value";
		a.method();
	}
}
