package sec03.exam02;

public enum Week2 {
	월, 화, 수, 목, 금, 토, 일
}
