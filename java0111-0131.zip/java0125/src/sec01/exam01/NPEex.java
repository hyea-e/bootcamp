package sec01.exam01;

class MyClass {
	void method() {}
}

public class NPEex {

	public static void main(String[] args) {
//		MyClass mc = null;
//		System.out.println(mc);
//		mc.method();
		int x;
		String data = null;
		System.out.println(data.toString());

	}

}
