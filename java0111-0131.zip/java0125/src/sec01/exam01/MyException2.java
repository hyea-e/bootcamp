package sec01.exam01;

public class MyException2 extends RuntimeException {
	public MyException2(String msg) {
		super(msg);
	}

}
