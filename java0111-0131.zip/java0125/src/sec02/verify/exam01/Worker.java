package sec02.verify.exam01;

public class Worker {
	public void start() {
		System.out.println("쉬고 있습니다.");
	}
}
