package sec03.exam02;

public class AniEx {

	public static void main(String[] args) {
		/* 추상 클래스는 객체생성이 안됩니다.
		Animal animal = new Animal();
		*/
	}

}
