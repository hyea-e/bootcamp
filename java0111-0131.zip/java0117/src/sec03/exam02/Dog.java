package sec03.exam02;

public class Dog extends Animal {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		
	}

	

}
