package chap7.prob3;

public class E extends B {

}
