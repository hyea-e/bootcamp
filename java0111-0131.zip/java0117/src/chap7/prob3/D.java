package chap7.prob3;

public class D extends B {

}
