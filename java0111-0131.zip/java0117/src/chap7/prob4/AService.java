package chap7.prob4;

public class AService extends MemberService {
	public void login() {
		System.out.println("A 로그인");
	}
}
