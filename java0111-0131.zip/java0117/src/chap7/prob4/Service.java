package chap7.prob4;

public class Service {
	public void login() {
		System.out.println("로그인");
	}
}
