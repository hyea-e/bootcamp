package chap7.prob4;

public class MemberService extends Service {

	public void login() {
		System.out.println("멤버 로그인");
	}
}
