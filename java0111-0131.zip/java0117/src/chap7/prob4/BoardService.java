package chap7.prob4;

public class BoardService extends Service {

}
