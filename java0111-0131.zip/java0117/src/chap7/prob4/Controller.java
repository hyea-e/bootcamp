package chap7.prob4;

public class Controller {
	public MemberService service;

	public void setService(MemberService service) {
		this.service = service;
	}


}
