package chap7.prob4;

public class Ex {

	public static void main(String[] args) {
		Controller controller = new Controller();
		AService bs = new AService();
		controller.setService(bs);

	}

}
