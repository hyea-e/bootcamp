package chap7.prob4;

public class DService extends BoardService {

}
