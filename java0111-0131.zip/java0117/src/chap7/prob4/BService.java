package chap7.prob4;

public class BService extends MemberService {

}
