package swing;

import javax.swing.JFrame;

public class JFramEx {

	public static void main(String[] args) {
		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setSize(300, 300);
		jf.setVisible(true);
	}

}
