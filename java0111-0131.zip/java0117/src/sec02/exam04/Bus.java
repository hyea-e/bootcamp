package sec02.exam04;

public class Bus extends Vehicle {

	@Override
	public void run() {
		System.out.println("버스 달린다.");
	}

}
