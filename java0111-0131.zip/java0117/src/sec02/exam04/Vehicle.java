package sec02.exam04;

public class Vehicle { // 차량
	public void run() {
		System.out.println("차량이 달린다.");
	}
}
