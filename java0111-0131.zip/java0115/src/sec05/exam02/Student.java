package sec05.exam02;

public class Student {
	String name;
	String hakbun;  // 학번
	int kor;
	int math;
	int eng;
}
