package sec01.exam02;

public class B {
	Ba s1;
	static Ba s2;
	static Bb s3;
	
	class Ba {}
	static class Bb {}
	

}
