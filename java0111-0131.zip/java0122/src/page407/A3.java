package page407;

public class A3 {
	void method() {
		class B {}
		class C {}
	}
}
