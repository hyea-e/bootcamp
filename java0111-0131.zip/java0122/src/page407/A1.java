package page407;

public class A1 {
	class B {}
}
