package page407;

public class A2 {
	static class B {}
}
