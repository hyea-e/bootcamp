package page412;



public class Account {
	Name name = new Name();
	static School school = new School();
	
	class Name {}
	static class School {}

}
