package page407;

public class A {
	class B {}
	static class C {}
	void method() {
		class D {}
	}
}
