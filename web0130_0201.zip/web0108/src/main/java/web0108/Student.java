package web0108;

public class Student {
	public static String[] names 
	                 = {"김하나", "강하나", "신용권"};
}
