INSERT INTO member (id, name) values (1, 'A')
INSERT INTO member (id, name) values (2, 'B')
INSERT INTO member (id, name) values (3, 'C')