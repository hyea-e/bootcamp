package com.studioj.springbootdeveloper.repository;

import com.studioj.springbootdeveloper.dao.Member;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.jdbc.Sql;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class MemberRepositoryTest {
    @Autowired
    MemberRepository memberRepository;

    //삭제
    @AfterEach
    public void cleanUp() {
        memberRepository.deleteAll();
    }

    @Sql("/insert-members.sql") //Test 실행 전 SQL 스크립트 실행
    @Test
    void getAllMembers() {
        //when
        List<Member> members = memberRepository.findAll();

        //then
        assertThat(members.size()).isEqualTo(3);
    }

    @Sql("/insert-members.sql")
    @Test
    void getMemberById() {
        //when
        Member member = memberRepository.findByName("C").get();

        //then
        assertThat(member.getId()).isEqualTo(3);
    }

    //입력
    @Test
    void saveMember() {
        //given
        Member member = new Member(1L, "A");

        //when
        memberRepository.save(member);

        //then
        assertThat(memberRepository.findById(1L).get().getName()).isEqualTo("A");
    }

    //여러명 입력
    @Test
    void saveMembers() {
        //given
        List<Member> members =List.of(new Member(2L, "B"), new Member(3L, "C"));

        //when
        memberRepository.saveAll(members);

        //then
        assertThat(memberRepository.findAll().size()).isEqualTo(2);
    }

    @Sql("/insert-members.sql")
    @Test
    void deleteMemberById() {
        //when
        memberRepository.deleteById(2L);

        //then
        assertThat(memberRepository.findById(2L).isEmpty()).isTrue();
    }

    //실제 서비스 코드에서 사용하지 않음
    //테스트 간의 격리를 보장하기 위해 사용
    //@Sql("/insert-members.sql")
    //@Test
    void deleteAll() {
        //when
        memberRepository.deleteAll();
        //then
        assertThat(memberRepository.findAll().size()).isZero();
    }

    //변경
    //@DataJpaTest에 @Transactional이 포함되어있다
    //서비스 코드에서 업데이트 기능을 사용하려면 반드시 메서드에 트랜젝션 애노케이션을 붙여야 함
    @Sql("/insert-members.sql")
    @Test
    void update() {
        //given
        Member member = memberRepository.findById(2L).get();

        //when
        member.changeName("BC");

        //then
        assertThat(memberRepository.findById(2L).get().getName()).isEqualTo("BC");
    }
}