package com.studioj.springbootdeveloper.controller;

import com.studioj.springbootdeveloper.dao.Member;
import com.studioj.springbootdeveloper.repository.MemberRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest //Test Application Context 생성
@AutoConfigureMockMvc //MockMvc 생성 및 자동 구성
class TestControllerTest {
    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    public MemberRepository memberRepository;

    @BeforeEach //Test 실행 전 실행 Method
    public void mockMvcSetUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @AfterEach //Test 실행 후 실행 Method
    public void cleanUp() {
        memberRepository.deleteAll();
    }

    @DisplayName("getAllMembers: 아티클 조회에 성공한다")
    @Test
    public void getALlMembers() throws Exception {
        //given : member 저장
        final String url = "/test";
        Member savedMember = memberRepository.save(new Member(1L, "김하나"));

        //when : memberList select API 호출
        final ResultActions result = mockMvc.perform(get(url).accept(MediaType.APPLICATION_JSON));

        //then : 응답 코드 200 OK, 반환받은 값 중 0번째 요소 id와 name이 저장된 값과 같은지 확인
        result
                .andExpect(status().isOk()) //HTTP 주요 응답 코드
                .andExpect(jsonPath("$[0].id").value(savedMember.getId()))
                .andExpect(jsonPath("$[0].name").value(savedMember.getName()));

        /*
        perform(): 요청을 전송하는 역할
        ResultActions 객체를 받으며, ResultActions 객체는 반환값을 검증하고 확인하는 andExpect() Method를 제공

        accept(): 요청을 보낼 때 무슨 타입으로 응답을 받을지 결정
        JSON, XML 다양한 타입이 존재

        andExpect(): 응답을 검증
        TestController에서 만든 API는 응답으로 OK(200)을 반환 .Ok를 사용해 응답 코드 OK인지 확인

        jsonPath("$[0].${필드명}"): JSON 응답값의 값을 가져오는 역할
        0번째 배열에 들어있는 객체의 id, name값을 가져오고 저장된 값과 같은지 확인
         */
    }

}