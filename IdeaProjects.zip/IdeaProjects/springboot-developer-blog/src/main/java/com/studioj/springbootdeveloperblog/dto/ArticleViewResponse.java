package com.studioj.springbootdeveloperblog.dto;

import com.studioj.springbootdeveloperblog.domain.Article;
import com.studioj.springbootdeveloperblog.domain.Comment;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@Getter
public class ArticleViewResponse {
    private Long id;
    private String title;
    private String content;
    private LocalDateTime createdAt;
    private String author;
    private List<Comment> comments; //댓글

    public ArticleViewResponse(Article article) {
        this.id = article.getId();
        this.title = article.getTitle();
        this.content = article.getContent();
        this.createdAt = article.getCreatedAt();
        this.author = article.getAuthor(); //oAuth 구현할 때
        this.comments = article.getComments(); //댓글
    }

    // 댓글 BlogApiComtrollerTest 코드 추가 > 10. AticleViewResponse 코드 추가
}
