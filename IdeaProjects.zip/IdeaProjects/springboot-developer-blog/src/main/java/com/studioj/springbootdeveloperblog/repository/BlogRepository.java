package com.studioj.springbootdeveloperblog.repository;

import com.studioj.springbootdeveloperblog.domain.Article;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BlogRepository extends JpaRepository<Article, Long> {
    //JpaRepository를 상속받을 때 엔티티 Article과 엔티티 PK Type Long을 인수로 사용
    //JpaRepository에서 제공하는 여러 메서드 사용 가능
}