package com.studioj.springbootdeveloperblog.repository;

import com.studioj.springbootdeveloperblog.domain.Comment;
import org.springframework.data.jpa.repository.JpaRepository;

// 댓글 만들기 Article 추가 > 03. CommentRepository 작성 > data.sql 수정 > AddCommentReuest 추가
public interface CommentRepository extends JpaRepository<Comment, Long> {
}
