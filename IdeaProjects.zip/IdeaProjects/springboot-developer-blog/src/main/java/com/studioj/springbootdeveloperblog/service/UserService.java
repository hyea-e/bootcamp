package com.studioj.springbootdeveloperblog.service;

import com.studioj.springbootdeveloperblog.domain.User;
import com.studioj.springbootdeveloperblog.dto.AddUserRequest;
import com.studioj.springbootdeveloperblog.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

// AddUserRequest > 7. UserService > UserApiController
// TokenAuthenticationFilter > 10. UserService 메서드 추가 > RefreshTokenService 생성
// 회원 정보 추가 메서드
@RequiredArgsConstructor
@Service
public class UserService {
    private final UserRepository userRepository;
//    private final BCryptPasswordEncoder bCryptPasswordEncoder;

//    public Long save(AddUserRequest dto) {
//        return userRepository.save(User.builder()
//                .email(dto.getEmail())
//                .password(bCryptPasswordEncoder.encode(dto.getPassword())) //패스워드 암호화 = 패스워드 저장 시 시큐리티를 설정하며 패스워드 인코딩용으로 등록한 빈을 사용해서 암호한 후 저장
//                .build()).getId();
//    }

    // 10.
    public Long save(AddUserRequest dto) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        return userRepository.save(User.builder()
                .email(dto.getEmail())
                .password(encoder.encode(dto.getPassword()))
                .build()).getId();
    }

    public User findById(Long userId) {
        return userRepository.findById(userId)
                 .orElseThrow(() -> new IllegalArgumentException("Unexpected user"));
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Unexpected user"));
    }
}
