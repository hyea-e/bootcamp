package com.studioj.springbootdeveloperblog.domain;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

@EntityListeners(AuditingEntityListener.class) //엔티티의 생성 및 수정 시간을 자동으로 감시하고 기록
@NoArgsConstructor(access = AccessLevel.PROTECTED) //기본생성자
@Getter
@Entity
public class Article {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "content", nullable = false)
    private String content;

    //327p
    @Column(name = "author", nullable = false)
    private String author;

    //327p
    @Builder
    public Article(String author, String title, String content) {
        this.title = title;
        this.content = content;
        this.author = author;
    }
    
    public void update(String title, String content) {
        this.title = title;
        this.content = content;
    }

    //엔티티가 생성될 때 생성 시간 저장
    @CreatedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    //엔티티가 수정될 때 수정 시간 저장
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // 댓글 만들기 01.Comment > 02.Article 추가 > CommentRepository 작성
    @OneToMany(mappedBy = "article", cascade = CascadeType.REMOVE)
    private List<Comment> comments;

}
