package com.studioj.springbootdeveloperblog.repository;

import com.studioj.springbootdeveloperblog.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

//domain 만들기 > 3. repository > UserDetailService
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}