package com.studioj.springbootdeveloperblog.dto;

import com.studioj.springbootdeveloperblog.domain.Article;
import com.studioj.springbootdeveloperblog.domain.Comment;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

// 댓글 만들기 data.sql 수정 > 05. AddCommentReuest > AddCommentResponse
// 댓글 추가 요청, 응답 시 사용할 DTO
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AddCommentRequest {
    private Long articleId;
    private String content;

    public Comment toEntity(String author, Article article) {
        return Comment.builder().article(article).content(content).author(author).build();
    }

}
