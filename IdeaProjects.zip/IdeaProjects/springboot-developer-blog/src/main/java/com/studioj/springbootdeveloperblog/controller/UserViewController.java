package com.studioj.springbootdeveloperblog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

// UserApiController > 9. UserViewController > 10. html (login, signup) > 11. UserApiController 수정
// 경로 접근 시 이동
@Controller
public class UserViewController {
    @GetMapping("/login")
    public String login() {
        return "oauthLogin";
    }

    @GetMapping("/signup")
    public String signup() {
        return "signup";
    }
}