package com.studioj.springbootdeveloperblog.dto;

import com.studioj.springbootdeveloperblog.domain.Comment;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

// 댓글 만들기 05. AddCommentReuest > 06. AddCommentResponse > BlogService 코드 추가
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AddCommentResponse {
    private Long id;
    private String content;

    public AddCommentResponse(Comment comment) {
        this.id = comment.getId();
        this.content = comment.getContent();
    }
}
