package com.studioj.springbootdeveloperblog.repository;

import com.studioj.springbootdeveloperblog.domain.RefreshToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

//RefreshToken(domain) > 8. RefreshTokenRepository > TokenFilter 구현
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
    Optional<RefreshToken> findByUserId(Long userId);
    Optional<RefreshToken> findByRefreshToken(String refreshToken);

    void deleteByUserId(Long userId);
}