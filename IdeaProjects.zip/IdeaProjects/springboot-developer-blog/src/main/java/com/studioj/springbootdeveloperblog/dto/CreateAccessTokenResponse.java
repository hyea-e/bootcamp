package com.studioj.springbootdeveloperblog.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

// CreateAccessTokenRequest > 14. CreateAccessTokenResponse > TokenApiController
@AllArgsConstructor
@Getter
public class CreateAccessTokenResponse {
    private String accessToken;
}
