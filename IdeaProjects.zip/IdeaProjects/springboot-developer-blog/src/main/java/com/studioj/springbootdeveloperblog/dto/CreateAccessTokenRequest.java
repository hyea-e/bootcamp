package com.studioj.springbootdeveloperblog.dto;

import lombok.Getter;
import lombok.Setter;

// TokenService > 13. CreateAccessTokenRequest > CreateAccessTokenResponse
@Getter
@Setter
public class CreateAccessTokenRequest {
    private String refreshToken;
}
