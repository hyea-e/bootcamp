package com.studioj.springbootdeveloperblog.dto;

import lombok.Getter;
import lombok.Setter;

// WebSecurityConfig > 6. AddUserRequest > UserService
// 회원 가입
@Getter
@Setter
public class AddUserRequest {
    private String email;
    private String password;
}
