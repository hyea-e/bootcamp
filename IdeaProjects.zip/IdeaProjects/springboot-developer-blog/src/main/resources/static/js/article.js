//삭제 기능
//delete-btn 설정한 id를 찾아 fetch()메서드를 통해 요청을 보낸다
// const deleteButton = document.getElementById("delete-btn");
//
// if(deleteButton) {
//     deleteButton.addEventListener('click', event => {
//         let id = document.getElementById('article-id').value;
//
//         fetch(`/api/articles/${id}`, {
//             method: 'DELETE'
//         })
//
//         //fetch가 완료되면 연이어 실행
//         .then(() => {
//             alert('삭제가 완료되었습니다');
//             //location.replace() 메서드는 실행 시 사용자의 웹 브라우저 화면을 현재 주소를 기반해 옮겨주는 역할
//             location.replace('/articles');
//         });
//     });
// }

// 수정 기능
// const modifyButton = document.getElementById('modify-btn');
//
// if (modifyButton) {
//     modifyButton.addEventListener('click', event => {
//         let params = new URLSearchParams(location.search);
//         let id = params.get('id');
//
//         fetch(`/api/articles/${id}`, {
//             method: 'PUT',
//             headers: {
//                 "Content-Type": "application/json",
//             },
//             body: JSON.stringify({
//                 title: document.getElementById('title').value,
//                 content: document.getElementById('content').value
//             })
//         })
//             .then(() => {
//                 alert('수정이 완료되었습니다.');
//                 location.replace(`/articles/${id}`);
//             });
//     });
// }

// 생성 기능
// const createButton = document.getElementById('create-btn');
//
// if (createButton) {
//     createButton.addEventListener('click', event => {
//         fetch('/api/articles', {
//             method: 'POST',
//             headers: {
//                 "Content-Type": "application/json",
//             },
//             body: JSON.stringify({
//                 title: document.getElementById('title').value,
//                 content: document.getElementById('content').value
//             })
//         })
//             .then(() => {
//                 alert('등록 완료되었습니다.');
//                 location.replace('/articles');
//             });
//     });
// }

// 토큰 기반 생성 기능
const createButton = document.getElementById('create-btn');

if (createButton) {
    createButton.addEventListener("click", (event) => {
        body = JSON.stringify({
            title: document.getElementById("title").value,
            content: document.getElementById("content").value,
        });
        function success() {
            alert("등록 완료되었습니다.")
            location.replace("/articles");
        }
        httpRequest("POST", "/api/articles", body, success, fail);
    });
}

function getCookie(key) {
    var result = null;
    var cookies = document.cookie.split(";");
    cookies.some(function (item) {
        item = item.replace(" ", "");

        var dic = item.split("=");

        if (key == dic[0]) {
            result = dic[1];
            return true;
        }
    });

    return result;
}

function httpRequest(method, url, body, success, fail) {
    fetch(url, {
        method: method,
        headers: {
            Authorization: "Bearer " + localStorage.getItem("access_token"),
            "Content-Type": "application/json",
        },
        body: body,
    }).then((response) => {
        if (response.ok) {
            return success();
        } else if (response.status === 401) {
            const refresh_token = getCookie("refresh_token");
            if (refresh_token) {
                return fetch("/api/token", {
                    method: "POST",
                    headers: {
                        Authorization: "Bearer " + refresh_token,
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        refreshToken: refresh_token,
                    }),
                })
                    .then((res) => {
                        if (res.ok) {
                            return res.json();
                        } else {
                            throw new Error("Refresh token request failed");
                        }
                    })
                    .then((result) => {
                        localStorage.setItem("access_token", result.accessToken);
                        // 재시도
                        return fetch(url, {
                            method: method,
                            headers: {
                                Authorization: "Bearer " + localStorage.getItem("access_token"),
                                "Content-Type": "application/json",
                            },
                            body: body,
                        });
                    })
                    .then((response) => {
                        if (response.ok) {
                            return success();
                        } else {
                            throw new Error("Request failed after token refresh");
                        }
                    })
                    .catch((error) => fail());
            } else {
                throw new Error("Refresh token is missing");
            }
        } else {
            throw new Error("Request failed");
        }
    }).catch((error) => fail());
}

// 삭제 기능
const deleteButton = document.getElementById("delete-btn");

if(deleteButton) {
    deleteButton.addEventListener("click", (event) => {
        let id = document.getElementById("article-id").value;
        function success() {
            alert("삭제가 완료되었습니다.");
            location.replace("/articles");
        }

        function fail() {
            alert("삭제 실패했습니다.");
            location.replace("/articles");
        }

        httpRequest("DELETE", "/api/articles/" + id, null, success, fail);
    });
}

// 수정 기능
const modifyButton = document.getElementById("modify-btn");

if(modifyButton) {
    modifyButton.addEventListener('click', event => {
        let params = new URLSearchParams(location.search);
        let id = params.get("id");

        body = JSON.stringify({
            title: document.getElementById("title").value,
            content: document.getElementById("content").value
        });

        function success() {
            alert("수정 완료되었습니다.");
            location.replace("/articles/" + id);
        }

        function fail() {
            alert("수정 실패했습니다.");
            location.replace("/articles/" + id);
        }

        httpRequest("PUT", "api/articles/" + id, body, success, fail);
    });
}

// 댓글 생성 기능
const commentCreateButton = document.getElementById('comment-create-btn');

if(commentCreateButton) {
    commentCreateButton.addEventListener('click', event => {
        articleId = document.getElementById('article-id').value;
        body = JSON.stringify({
            articleId: articleId,
            content: document.getElementById('content').value
        });

        function success() {
            alert('등록 완료되었습니다.');
            location.replace('/articles/' + articleId);
        };

        function fail() {
            alert('등록 실패했습니다.');
            location.replace('/articles/' + articleId);
        };

        httpRequest('POST', '/api/comments', body, success, fail)
    });
}