package com.mustache329.sectionA;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.mustache329.sectionA.entity.Product;
import com.mustache329.sectionA.entity.User;
import com.mustache329.sectionA.service.ProductService;
import com.mustache329.sectionA.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class LearnMustacheApplicationTests {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	@Test
	void userCount() {
		log.info("User Count: {}", userService.count());
	}
	
	@Test
	void userList() {
		log.info("User List: {}", userService.getUserList());
	}
	
	//@Test
	void insertUser() {
		User user = User.builder().name("김이나").city("서울").street("영등포구").zipcode("150-843").build();
		userService.addUser(user);
	}
	
	@Test
	void productCount() {
		log.info("Product Count: {}", productService.count());
	}
	
	@Test
	void productList() {
		log.info("Product List: {}", productService.getProductList());
	}
	
	@Transactional
	@Test
	void addProduct() {
		productService.addProduct(new Product("Jacket", 380000));
		productService.addProduct(new Product("T-shirt", 89000));
		productService.addProduct(new Product("Pants", 120000));
	}
	

}
