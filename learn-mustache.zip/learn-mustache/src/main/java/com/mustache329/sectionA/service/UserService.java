package com.mustache329.sectionA.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mustache329.sectionA.entity.User;
import com.mustache329.sectionA.repository.UserMapper;

@Service
public class UserService {
	
	@Autowired
	private UserMapper userMapper;
	
	public int count() {
		return userMapper.count();
	}
	
	public List<User> getUserList() {
		return userMapper.selectUserList();
	}
	
	public User getUserId(Long id) {
		return userMapper.selectUserId(id);
	}
	
	@Transactional
	public void addUser (User user) {
		userMapper.insertUser(user);
	}

}
