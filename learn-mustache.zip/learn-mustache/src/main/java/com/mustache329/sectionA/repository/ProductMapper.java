package com.mustache329.sectionA.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.mustache329.sectionA.entity.Product;

@Mapper
public interface ProductMapper {
	
	@Select("select count(*) from product")
	int count();
	
	@Select("select * from product")
	List<Product> selectProductList();
	
	Product selectProductId(Long id);
	
	void insertProduct(Product product);

}
/* 2.
MyBatis - Mapper interface와 Service Class를 함께 사용하여 데이터 액세스와 비즈니스 로직을 분리

Mapper interface - 데이터 액세스 계층에서 SQL 쿼리를 정의하고 실행하는 역할을 담당

Service Class - 비즈니스 로직을 구현, Mapper를 호출하여 데이터베이스와의 상호 작용을 처리

*/