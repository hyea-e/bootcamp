package com.mustache329.sectionA.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mustache329.sectionA.entity.Order;
import com.mustache329.sectionA.repository.OrderMapper;

@Service
public class OrderService {
	
	@Autowired
	OrderMapper orderMapper;
	
	public int count() {
		return orderMapper.count();
	}
	
	public List<Order> getOrderList(){
		return orderMapper.selectAllOrder();
	}

}
