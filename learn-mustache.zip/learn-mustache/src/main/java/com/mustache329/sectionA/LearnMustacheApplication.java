package com.mustache329.sectionA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnMustacheApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnMustacheApplication.class, args);
	}

}