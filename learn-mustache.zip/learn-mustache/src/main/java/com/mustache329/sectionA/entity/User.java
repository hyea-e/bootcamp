package com.mustache329.sectionA.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Builder;
import lombok.NonNull;
import lombok.ToString;

@ToString
@Builder
@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userId;
	@NonNull
	private String name;
	@NonNull
	private String city;
	@NonNull
	private String street;
	@NonNull
	private String zipcode;

}

/*
@Id - 기본 키(primary key) 필드

@GeneratedValue - 기본 키의 값을 자동으로 생성하는 방법을 지정

= GeneratedValue 어노테이션의 strategy 속성에 GenerationType 열거형을 사용하여 기본 키 생성 전략을 지정

@Entity - JPA(Java Persistence API) 엔터티를 나타내는 클래스임을 표시
		  해당 클래스가 데이터베이스의 테이블과 매핑되는 엔터티임을 JPA에 알려준다
		  
@Getter(..) - Lombok 라이브러리에서 제공하는 어노테이션

= Entity 어노테이션을 사용하더라도 Lombok의 어노테이션들을 함께 사용할 수 있다

*/