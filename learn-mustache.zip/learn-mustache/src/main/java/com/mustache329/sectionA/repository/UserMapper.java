package com.mustache329.sectionA.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.mustache329.sectionA.entity.User;

@Mapper
public interface UserMapper {
	
	@Select("select count(*) from user")
	int count();
	
	@Select("select * from user")
	List<User> selectUserList();
	
	User selectUserId(Long id);
	
	void insertUser(User user);
}

/* 1.
@Mapper - ORM(Object-Relational Mapping) 프레임워크에서 사용

MyBatis는 이러한 매퍼 인터페이스를 스캔하여 해당 인터페이스에 대한 구현체를 자동으로 생성하고 SQL 쿼리를 실행
*/