package com.mustache329.sectionA.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.NonNull;

@Entity
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long orderId;
	
	@ManyToOne
    @JoinColumn(name = "user_id")
    @NonNull
    private String userId;
	
	@ManyToOne
    @JoinColumn(name = "product_id")
    @NonNull
    private String productId;
	
    private int count;
    
	@NonNull
	private LocalDateTime orderTime;
}
