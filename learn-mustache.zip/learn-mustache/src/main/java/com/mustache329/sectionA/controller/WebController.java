package com.mustache329.sectionA.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mustache329.sectionA.entity.Product;
import com.mustache329.sectionA.service.OrderService;
import com.mustache329.sectionA.service.ProductService;
import com.mustache329.sectionA.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class WebController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	ProductService productService;
	
	@Autowired
	OrderService orderService;
	
	@GetMapping("/")
	public String main(Model model) {
		return "main";
	}
	/*
	 Model - MVC 아키텍처에서 View와 Controller 간의 데이터를 전달하는데 사용되는 객체
	 과정 - Controller가 해당 View로 이동, Model 객체에 추가된 데이터는 해당 View에서 사용
	 */
	
	@GetMapping("/items")
	public String Productlist(Model model) {
		model.addAttribute("list", productService.getProductList());
		return "list";
	}
	/*
	 addAttribute(Key, Value);
	 */
	
	@GetMapping("/items/new")
	public String productAdd() {
		return "plusItem";
	}
	
	@PostMapping("/new")
	public String AddNew(Product product) {
		log.info("prooduct: {}", product.getProductName());
		log.info("prooduct: {}", product.getProductPrice());
		productService.addProduct(product);
		return "redirect:/items";
	}

}
