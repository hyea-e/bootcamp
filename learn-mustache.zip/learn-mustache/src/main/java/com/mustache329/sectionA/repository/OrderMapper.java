package com.mustache329.sectionA.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.mustache329.sectionA.entity.Order;

@Mapper
public interface OrderMapper {
	
	@Select("select count(*) from order")
	int count();
	
	@Select("select * from order")
	List<Order> selectAllOrder();

}
