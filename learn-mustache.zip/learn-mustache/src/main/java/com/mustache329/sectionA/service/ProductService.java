package com.mustache329.sectionA.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mustache329.sectionA.entity.Product;
import com.mustache329.sectionA.repository.ProductMapper;

@Service
public class ProductService {
	
	@Autowired
	private ProductMapper productMapper;
	
	public int count() {
		return productMapper.count();
	}
	
	public List<Product> getProductList() {
		return productMapper.selectProductList();
	}
	
	public Product getProcuctId(Long id) {
		return productMapper.selectProductId(id);
	}
	
	@Transactional
	public void addProduct(Product product) {
		productMapper.insertProduct(product);
	}
	
}
