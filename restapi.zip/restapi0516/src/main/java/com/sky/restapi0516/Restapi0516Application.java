package com.sky.restapi0516;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restapi0516Application {

    public static void main(String[] args) {
        SpringApplication.run(Restapi0516Application.class, args);
    }

}
