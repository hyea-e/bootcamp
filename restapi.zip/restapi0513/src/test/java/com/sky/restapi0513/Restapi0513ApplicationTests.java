package com.sky.restapi0513;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restapi0513ApplicationTests {

    @Test
    void contextLoads() {
    }

}
