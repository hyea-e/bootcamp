package com.sky.restapi0513.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TestRequestBodyDTO {
    private int id;
    private String message;
}
