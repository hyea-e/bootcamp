package com.study.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Swagger0907ApplicationTests {

	@Test
	void contextLoads() {
	}

}
