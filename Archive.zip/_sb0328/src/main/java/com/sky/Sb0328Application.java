package com.sky;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb0328Application {

	public static void main(String[] args) {
		SpringApplication.run(Sb0328Application.class, args);
	}

}
