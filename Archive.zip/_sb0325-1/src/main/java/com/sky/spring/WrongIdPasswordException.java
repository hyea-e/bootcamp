package com.sky.spring;

public class WrongIdPasswordException extends RuntimeException {

}
