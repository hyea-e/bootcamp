package com.sky.spring;

public class MemberNotFoundException extends RuntimeException {

}
