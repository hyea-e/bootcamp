package com.sky.service;

public class WrongIdPasswordException extends RuntimeException {

}
