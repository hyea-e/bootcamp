package com.sky;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp0325Application {

	public static void main(String[] args) {
		SpringApplication.run(Sp0325Application.class, args);
	}

}
