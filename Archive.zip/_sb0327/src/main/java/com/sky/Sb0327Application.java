package com.sky;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb0327Application {

	public static void main(String[] args) {
		SpringApplication.run(Sb0327Application.class, args);
	}

}
