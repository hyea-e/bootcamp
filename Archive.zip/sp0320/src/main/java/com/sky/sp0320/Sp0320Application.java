package com.sky.sp0320;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp0320Application {
// 이것은 스프링부트    
	public static void main(String[] args) {
		SpringApplication.run(Sp0320Application.class, args);
	}

}
