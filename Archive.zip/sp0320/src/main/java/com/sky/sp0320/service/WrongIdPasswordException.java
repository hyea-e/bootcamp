package com.sky.sp0320.service;

public class WrongIdPasswordException extends RuntimeException {

}
