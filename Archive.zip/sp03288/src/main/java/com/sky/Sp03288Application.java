package com.sky;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp03288Application {

	public static void main(String[] args) {
		SpringApplication.run(Sp03288Application.class, args);
	}

}
