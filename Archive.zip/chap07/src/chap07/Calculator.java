package chap07;

public interface Calculator {
	public long factorial(long num);  // 3! = 3*2*1
}
