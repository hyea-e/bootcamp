package movies.spring.data.neo4j.movies;

public record MovieResultDto(Movie movie) {
}
