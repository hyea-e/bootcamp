package member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberDao {
//	private JdbcUtil util = JdbcUtil.getInstance();
	public Connection getConnection() {
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "scott";
		String pw = "tiger";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pw);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return conn;
	}

	// 로그인
	public MemberDto isValidUser(String memberid, String memberpw) {
		MemberDto dto = null;
		String query = "SELECT * FROM MEMBER_H WHERE MEMBERID = ? AND MEMBERPW = ?";
		try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(query);) {
			pstmt.setString(1, memberid);
			pstmt.setString(2, memberpw);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				dto = new MemberDto();
				dto.setNum(rs.getInt("num"));
				dto.setMemberid(rs.getString("memberid"));
				dto.setMemberpw(rs.getString("memberpw"));
				dto.setNickname(rs.getString("nickname"));
			}

		} catch (SQLException e) {
			System.out.println("사용자 인증 실패");
			e.printStackTrace();
		}
		return dto;
	}

	// 회원 조회
	public List<MemberDto> selectAll() {
		List<MemberDto> members = new ArrayList<>();
		String query = "SELECT * FROM MEMBER_H";

		try (Connection conn = getConnection();
				PreparedStatement pstmt = conn.prepareStatement(query);
				ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				MemberDto dto = new MemberDto();
				dto.setNum(rs.getInt("num"));
				dto.setMemberid(rs.getString("memberid"));
				dto.setMemberpw(rs.getString("memberpw"));
				dto.setNickname(rs.getString("nickname"));
				members.add(dto);
			}

		} catch (SQLException e) {
			System.out.println("회원 전체 조회 예외");
			e.printStackTrace();
		}
		return members;
	}

	// 회원 등록
	public int register(MemberDto dto) {
		int result = 0;
		String query = "INSERT INTO MEMBER_H (NUM, MEMBERID, MEMBERPW, NICKNAME, REGDATE) "
				+ "VALUES (MEMBER_H_SEQ.NEXTVAL, ?, ?, ?, SYSDATE)";
		try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(query);) {
			pstmt.setString(1, dto.getMemberid());
			pstmt.setString(2, dto.getMemberpw());
			pstmt.setString(3, dto.getNickname());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("회원 등록 예외");
			e.printStackTrace();
		}
		return result;
	}

	// 회원 선택 뷰
	public MemberDto selectView(String num) {
		MemberDto dto = new MemberDto();
		String query = "SELECT * FROM MEMBER_H WHERE num = ?";

		try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, num);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				dto.setNum(rs.getInt("num"));
				dto.setMemberid(rs.getString("memberid"));
				dto.setMemberpw(rs.getString("memberpw"));
				dto.setNickname(rs.getString("nickname"));
				dto.setRegdate(rs.getDate("regdate"));
				System.out.print(dto);
			}

		} catch (SQLException e) {
			System.out.println("회원 상세 보기 예외 발생");
			e.printStackTrace();
		}
		return dto;
	}

	// 회원 수정
	public int updateMember(MemberDto dto) {
		int result = 0;
		String query = "UPDATE MEMBER_H SET MEMBERPW = ?, NICKNAME = ?, MEMBERID = ? WHERE NUM = ?";

		try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, dto.getMemberpw());
			pstmt.setString(2, dto.getNickname());
			pstmt.setString(3, dto.getMemberid());
			pstmt.setInt(4, dto.getNum());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("회원 수정 예외");
			e.printStackTrace();
		}
		return result;
	}

	// 회원 삭제
//    public int deleteMember(MemberDto dto) {
//    	int result = 0;
//    	
//        String query = "DELETE FROM MEMBER_H WHERE NUM = ?";
//        try (Connection conn = util.getConnection();
//            PreparedStatement pstmt = conn.prepareStatement(query)){
//        	pstmt.setInt(1, dto.getNum());
//            result = pstmt.executeUpdate();
//            
//        } catch (SQLException e) {
//            System.out.println("회원 삭제 예외");
//            e.printStackTrace();
//        }
//        return result;
//    }
	//회원 탈퇴
//	public int withdrawMember(MemberDto dto) {
//		int result = 0;
//		String query = "DELETE FROM MEMBER_H WHERE NUM  = ?";
//		
//		try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
//			pstmt.setInt(1, dto.getNum());
//			result = pstmt.executeUpdate();
//		} catch (SQLException e) {
//			System.out.println("회원 탈퇴 예외");
//			e.printStackTrace();
//		}
//		return result;
//	}
	
	public int withdrawMember(MemberDto dto) {
		int result = 0;
		String query = "DELETE FROM MEMBER_H WHERE MEMBERID  = ?";
		
		try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, dto.getMemberid());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("회원 탈퇴 예외");
			e.printStackTrace();
		}
		return result;
	}
}
