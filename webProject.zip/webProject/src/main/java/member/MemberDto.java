package member;

import java.sql.Date;

public class MemberDto {
	private int num;
	private String memberid;
	private String memberpw;
	private String nickname;
	private Date regdate;
	
	public MemberDto() {}
	
	public MemberDto(int num, String memberid, String memberpw, String nickname, Date regdate) {
		super();
		this.num = num;
		this.memberid = memberid;
		this.memberpw = memberpw;
		this.nickname = nickname;
		this.regdate = regdate;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getMemberpw() {
		return memberpw;
	}
	public void setMemberpw(String memberpw) {
		this.memberpw = memberpw;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	@Override
	public String toString() {
		return "MemberDto [num=" + num + ", memberid=" + memberid + ", memberpw=" + memberpw + ", nickname=" + nickname
				+ ", regdate=" + regdate + "]";
	}
	
	
}
