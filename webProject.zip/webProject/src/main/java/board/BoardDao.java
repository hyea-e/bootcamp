package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import util.JdbcUtil;

public class BoardDao {
	private JdbcUtil util = JdbcUtil.getInstance();

	// 검색 조건에 맞는 게시물 개수 반환
	public int selectCount(Map<String, Object> map) {
		int totalCount = 0;

		// 게시물 수를 얻어오는 쿼리문
		String query = "SELECT COUNT(*) FROM BOARD_H ";
		if (map.get("searchWord") != null) {
			query += "where" + map.get("searchField") + "" + "like '%" + map.get("searchWord") + "%'";
		}

		try (Connection conn = util.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {
			rs.next();
			totalCount = rs.getInt(1);
		} catch (SQLException e) {
			System.out.println("게시물 구하는 중 예외 발생");
			e.printStackTrace();
		}

		return totalCount;

	}

	// 검색 조건에 맞는 게시물 목록 반환
	public List<BoardDto> selectList(Map<String, Object> map) {
		List<BoardDto> list = new Vector<BoardDto>();

		String query = "SELECT * FROM BOARD_H ";

		if (map.get("searchWord") != null) {
			query += "where" + map.get("searchField") + "" + "like '%" + map.get("searchWord") + "%'";
		}

		query += " order by num desc ";

		try (Connection conn = util.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query)) {

			while (rs.next()) {
				BoardDto dto = new BoardDto();
				dto.setNum(rs.getInt("num"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setNickname(rs.getString("nickname"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setViews_count(rs.getInt("views_count"));
				list.add(dto);
			}

		} catch (Exception e) {
			System.out.println("게시물 조회 중 예외 발생");
			e.printStackTrace();
		}

		return list;
	}

	public int insertWrite(BoardDto dto) {
		int result = 0;

		String query = "INSERT INTO BOARD_H (num, title, content, nickname, postdate, views_count) "
				+ "VALUES (BOARD_H_SEQ.NEXTVAL, ?, ?, ?, SYSDATE, 0)";

		try (Connection conn = util.getConnection();
		    PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getNickname());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("게시물 입력 중 예외 발생");
			e.printStackTrace();
		}

		return result;
	}

	public BoardDto selectView(String num) {
		BoardDto dto = new BoardDto();
		String query = "select * from BOARD_H where num = ?";

		try (Connection conn = util.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, num);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				dto.setNum(rs.getInt("num"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setNickname(rs.getString("nickname"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setViews_count(rs.getInt("views_count"));

			}

		} catch (SQLException e) {
			System.out.println("게시물 상세 보기 예외 발생");
			e.printStackTrace();
		}

		return dto;
	}

	public void updateVisitCount(String num) { // 수정함

		try (Connection conn = util.getConnection();
		    PreparedStatement pstmt = conn.prepareStatement("UPDATE BOARD_H SET views_count = views_count + 1 WHERE num = ?")) {
			pstmt.setString(1, num);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("게시물 조회수 증가 예외 발생");
			e.printStackTrace();
		}
	}

	public int updateEdit(BoardDto dto) {
		int result = 0;
		String query = "update BOARD_H set title=?, content=? where num=?";
		try (Connection conn = util.getConnection();
		    PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setInt(3, dto.getNum());

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("게시물 수정 중 예외 발생");
			e.printStackTrace();
		}

		return result;
	}
	public int deletePost(BoardDto dto) {
	    int result = 0;
	    String query = "DELETE FROM BOARD_H WHERE num = ?";

	    try (Connection conn = util.getConnection();
	        PreparedStatement pstmt = conn.prepareStatement(query)) {
	        pstmt.setInt(1, dto.getNum());
	        result = pstmt.executeUpdate();

	    } catch (SQLException e) {
	        System.out.println("게시물 삭제 중 예외 발생");
	        e.printStackTrace();
	    }
	    return result;
	}

}