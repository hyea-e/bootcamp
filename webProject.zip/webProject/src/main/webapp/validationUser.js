//사용자 입력값 유효성 검사
function validateUserForm(form) {
	var memberid = form.memberid.value;
	var memberpw = form.memberpw.value;
	var nickname = form.nickname.value;

	if (!memberid) {
		alert("이메일을 입력하세요");
		return false;
	}
	if (!isValidEmail(memberid)) {
		alert("올바른 이메일 형식이 아닙니다");
		return false;
	}
	if (!memberpw) {
		alert("비밀번호를 입력하세요");
		return false;
	}
	if (!nickname) {
		alert("닉네임을 입력하세요");
		return false;
	}
	// 모든 유효성 검사를 통과했을 때 true 반환
	return true;
}

// 이메일 형식인지 확인하는 함수
function isValidEmail(email) {
	var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
	return emailRegex.test(email);
}

/*
function checkForName() {
	var input = document.querySelector("#memberpw").value;
	var regex = /\d/; //숫자를 나타내는 정규식

	var nameErrorLabel = document.querySelector("#memberpwError");
	if (regex.test(input)) {
		nameErrorLabel.style.display = "block";
	} else {
		nameErrorLabel.style.display = "none";
	}
}
*/