package sec03.exam01;

public class Hello {

	public static void main(String[] args) {
		var z = 300;
		var z1 = 3.14;
		var str = "가나다";
		
		int y = 0b100;
		long x = 10000000000000L;
		System.out.println("Hello World");
		aaa();
	}
	
	public static void aaa() {
		System.out.println("aaa");
	}

}
