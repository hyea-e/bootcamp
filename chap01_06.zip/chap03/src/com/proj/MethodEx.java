package com.proj;

public class MethodEx {

	
	
	public static void main(String[] args) {
		String str = input();  // 호출
		System.out.println(str);
	}
	
	public static String input() { // 선언부
		String str = "aaa";
		return str;
		
	}
	
}
