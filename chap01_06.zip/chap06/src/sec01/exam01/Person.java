package sec01.exam01;

public class Person {
	String name;
	int age;

	public static void main(String[] ar) {
		Person p = new Person();
	}
}

class Aaa {
	
}

class Bbb {
	
}
