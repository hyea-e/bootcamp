package sec01.exam01;

public class StudentEx {

	public static void main(String[] args) {
		System.out.println("StudentEx");
		Student st = null;
		st = new Student();
		Student st1 = new Student();
		Student st2 = new Student();
		Student st3 = new Student();
		Student st4 = new Student();
	}

}
