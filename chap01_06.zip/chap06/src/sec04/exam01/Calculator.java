package sec04.exam01;

public class Calculator {
	int plus(int x, int y) {
		return x+y;
	}

	double plus(double x, double y) {
		return x+y;
	}
}
