package sec05.exam01;

public class AnimalEx {

	public static void main(String[] args) {
		Animal ani = new Animal();
//		ani.name = "사자";
		ani.setName("사자");
	}

}
