package sec02.exam01;

public class PrintEx {

	public static void main(String[] args) {
		System.out.printf("%02.6f", 3.141592);

	}

}
